const mongoose = require('mongoose');

const DonateSchema = new mongoose.Schema({
  Donation_amount : Number,
  card_number : Number,
});

module.exports = mongoose.model('Donate', DonateSchema);