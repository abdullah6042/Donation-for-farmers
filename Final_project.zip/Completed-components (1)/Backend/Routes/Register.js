const express = require('express');
const router = express.Router();
const Contact = require('../Model/contact');

router.post('/', async (req, res) => {
  const { name, email, passowrd } = req.body;

  try {
    const newRegister = new Register({ name, email, message });
    await newRegister.save();
    res.status(201).json({ message: 'User Register in successfully' });
  } catch (error) {
    console.error('Error Register in:', error);
    res.status(500).json({ error: 'Failed to Register' });
  }
});

module.exports = router;
