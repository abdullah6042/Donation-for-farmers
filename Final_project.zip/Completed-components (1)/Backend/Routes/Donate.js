const express = require('express');
const router = express.Router();
const Donate = require('../Model/donate');

app.post('/api/donate', async (req, res) => {
    const { donateAmount, cardNumber } = req.body;
  
    try {
      const newDonation = new Donate({ donateAmount, cardNumber });
      await newDonation.save();
      res.status(201).json({ message: 'Contact message sent successfully' });
    } catch (error) {
      console.error('Error saving donation:', error);
      res.status(500).json({ error: 'Failed to save donation' });
    }
  });

  module.exports = router;