import React, { useState } from "react";
import Newsletter from "./Newsletter";
import Approved from "./Approved";

function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:5000/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, message }),
      });

      if (response.ok) {
        alert('Contact message sent successfully');
        setName('');
        setEmail('');
        setMessage('');
      } else {
        alert('Failed to send contact message');
      }
    } catch (error) {
      console.error('Error sending contact message:', error);
      alert('Failed to send contact message');
    }
  };


  return (
    <>
      <div className='bg-[url("https://plus.unsplash.com/premium_photo-1661901843315-899899a4be86?q=80&w=2121&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-center h-full w-full'>
        <p className="text-6xl p-28 text-white font-bold">Contact Us</p>
      </div>
      <div>
        <p className="text-green-600 p-10 font-bold text-3xl">Contact Us</p>
        <p className="p-10">
          Thank you for your interest in our work here at Green Thumb Farm. If
          you would like to get in touch, email us at
          admin@greenthumbfarm.org.au or fill in the form below and one of our
          team will be in touch ASAP.{" "}
        </p>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            className="w-3/5 h-10 outline-none border-2 mb-5"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
          />
          <input
            type="text"
            className="w-3/5 h-10 outline-none border-2 mb-5"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="E-mail"
          />
          <textarea
            className="h-44 w-3/5 border-2 outline-none"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Message"
          ></textarea>
          <button type="submit">SEND</button>
        </form>
      </div>

      <div></div>
      <div className="h-96 bg-slate-200 flex justify-center pl-28 pr-28 mt-10">
        <div>
          <span className="text-green-400 text-3xl font-bold mt-10 mb-10 inline-block">
            How to find us
          </span>{" "}
          <br />
          <span className="text-xl">
            We are located at the Samford Farm Precinct - 2204 Mt Samson Rd,
            Samford <br />
            Valley, Qld, 4520.
          </span>
          <br />
          <span className="inline-block mt-5 text-xl">
            Parking // There is free parking on site. <br /> Take the first left
            after the glasshouses, and this takes you to our carpark.
          </span>
        </div>
        <div className="flex">
          <div>
            <span className="inline-block text-3xl mt-10 text-green-400 font-bold">
              How to get involved
            </span>{" "}
            <br />
            <span className="inline-block mt-10 text-xl">
              You can keep up to date with our programs by signing up to our
              newsletter below. We would love you to follow us on Facebook.
            </span>
          </div>
        </div>
      </div>
      <Newsletter />
      <Approved />
    </>
  );
}

export default Contact;
