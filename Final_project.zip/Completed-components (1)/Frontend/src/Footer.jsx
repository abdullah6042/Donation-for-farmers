import React from 'react'
import Navbar from './Navbar'

function Footer() {
    return (
        <>
            <div className='bg-zinc-600 h-screen'>
                <center>
                    <img src="/favicon.png" alt="" width={100} className='bg-transparent'/>
                </center>
                <p className='text-center text-green-300 text-sm'>
                    Find us at the Samford Farm Precinct - 2204 Mt Samson Rd, Samford Valley Qld 4520 <br /> <br />

                    Copyright © 2023 Green Thumb Farm Association Inc. <br /> <br />

                    Terms & Conditions | Privacy Policy
                </p>
                {/* <Navbar /> */}
            </div>
        </>
    )
}

export default Footer
