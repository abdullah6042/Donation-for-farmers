import React from 'react'

function Donors() {
    return (
        <>
            <div className='bg-[url("https://images.pexels.com/photos/955395/pexels-photo-955395.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2")] bg-cover bg-no-repeat w-full pt-40 pb-20 mb-20 h-[50vh]'>
                <div>
                    <p className='text-center text-white text-3xl font-bold'>Our Grant Donors</p>
                    <p className='text-center mt-10 text-xl'>Thank you!</p>
                </div>
            </div>
            <div>
                <center>
                    <img src="/favicon.png" alt="" width={150} />
                    <p className='mt-10 mb-10 text-xl'>Building a community garden truly takes a village! We rely on generous grants to cover our infrastructure and setup costs. We are deeply grateful for this support, which allows us to create an enriching space and give back to our community.</p>
                </center>
                <div>
                    <div className='flex'>
                        <img src="/comp1.png" alt="" />
                        <p className='ml-20 mt-10'>2023 - we were awarded $11,000 funding of through the  Facilities Grant which supported the establishment of our Irrigation system and earthworks to create the mandala. <br /><br />

                            2023 -  we were awarded funding of $10,000 which contributed toward the irrigation system.

                            2024 - we were awarded $6600 which has allowed us to purchase equipment for our schools program including a shade marquee for school groups, rugs, and native beehive. </p>
                    </div>
                    <div className='flex'>
                        <img src="/comp2.png" alt="" />
                        <p className='ml-28 mt-10'>2023 - we were awarded $11,000 funding of through the  Facilities Grant which supported the establishment of our Irrigation system and earthworks to create the mandala. <br /><br />
                            2024 - we were awarded $2347 funding through the Community Support Grant which we are using to purchase native bee hives, and OHS equipment for volunteers</p>

                    </div>
                    <div className='flex'>
                        <img src="/comp3.png" alt="" />
                        <p className='ml-52 mt-10'>2023 - we were awarded $5900 funding to support the overhead costs for establishing Green Thumb Farm. <br /><br />

                            2023 - we were awarded $4600 funding to support the establishment of our weekend education program. </p>

                    </div>
                    <div className='flex'>
                        <img src="/comp10.png" alt="" />
                        <p className='ml-52 mt-10'>

                            2024 -  we were awarded funding of $3000 towards our Schools Program.</p>
                    </div>
                </div>
            </div>
            <div className='bg-[url("https://images.unsplash.com/photo-1533460004989-cef01064af7e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat w-full pt-20 pb-10 h-[50vh] mt-10'>
            </div>
        </>
    )
}

export default Donors
