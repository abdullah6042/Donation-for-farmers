import React from 'react'

function Team() {
  return (
    <>
      <div className='bg-[url("https://plus.unsplash.com/premium_photo-1668376939292-bd6953dd1bac?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-center items-center w-full pt-20 pb-20 mb-20'>
        <p className='text-white text-3xl font-bold'>The Green Thumb Farm Team</p>
      </div>
      <div className='container mx-auto p-6'>
        <h1 className='text-2xl font-bold mb-6 text-center text-green-600'>Our Volunteer Management Team</h1>
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10'>
          <div className='text-center'>
            <img src="/p1.png" alt="SEAN FITZGERALD" className='w-full h-auto mx-auto' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>SEAN FITZGERALD</span>
            <p className='text-sm'>
              PRESIDENT // Sean is a happily retired commercial lawyer. He has broad experience gained in law firms, financial services and property development operations. His final eighteen years in practice were spent  in-house as head of legal services for the former Redcliffe City Council and the amalgamated Moreton Bay Regional Council. Sean is committed to environmental protection and addressing the climate crisis, in particular. He knows that while comprehensive, cooperative action is required by all governments, regardless of ideology, Sean also firmly believes that action by individuals is essential. In this respect the Green Thumb Farm ethos of growing sustainably and locally is paramount. Sean and his family live at Mount Samson.
            </p>
          </div>
          <div className='text-center'>
            <img src="/p2.png" alt="NICOLE WAILES" className='w-full h-auto mx-auto' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>NICOLE WAILES</span>
            <p className='text-sm'>
              TREASURER // Nicole brings diverse finance experience to the table, having led teams across various sectors including in media, software, energy, consultancy, and not for profits. As a Chartered Accountant with a Graduate Certificate in Financial Planning, she combines her expertise with a passion for helping startups and scale-ups optimise their financial and operational processes. Beyond the numbers, Nicole and her family enjoy embracing healthy living, spending time outdoors, growing what they can, and making eco-conscious choices.
            </p>
          </div>
          <div className='text-center'>
            <img src="/p3.png" alt="NICOLE WAILES" className='w-full h-auto mx-auto' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>NICOLE WAILES</span>
            <p className='text-sm'>
              FOUNDER & SECRETARY //Susanne has an unwavering commitment to advocating for re-localising food growing, recognizing its pivotal role in cultivating healthier and more resilient communities. She is the founder and Head of Operations at Green Thumb Farm, she launched the Moreton Bay Farm Trail in 2024, and co-founded the Samford Edible Garden Trail in 2020. She is passionate about reconnecting people, and especially children with how food is grown, believing it is the key to fostering resilient and thriving local communities.
            </p>
          </div>
          <div className='text-center'>
            <img src="/p4.png" alt="NICOLE WAILES" className='w-full h-auto mx-auto' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>NICOLE WAILES</span>
            <p className='text-sm'>
              DIRECTOR // Simon, with over 20 years in the food service sector, is spearheading the sustainability efforts at a leading global food service provider. Starting as a chef, he's grown a passion for food and sustainable practices. Currently, he's pivotal in achieving net zero targets, balancing high-quality standards and commercial viability with environmental concerns. This role is Simon's way of contributing to the industry that shaped his career, marking a significant step in its sustainable evolution.
            </p>
          </div>
        </div>
      </div>
      <div className='container mx-auto p-6'>
        <h1 className='text-2xl font-bold mb-6 text-center text-green-600'>Our Volunteer Operations Team</h1>
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10'>
          <div className='text-center'>
            <img src="https://plus.unsplash.com/premium_photo-1664475737086-fe5e7d0bb7f4?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="SEAN FITZGERALD" className='w-full h-auto mx-auto rounded-full border-4 border-green-500 ' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>SUSANNE ENGELHARD</span>
            <p className='text-sm'>
            HEAD OF OPERATIONS // Susanne wears many hats at Green Thumb. She oversees the business side of the Farm, is our chief grant writer, teaches workshops, but her favourite job of all is dreamer of big ideas. 
            </p>
          </div>
          <div className='text-center'>
            <img src="https://images.pexels.com/photos/1023404/pexels-photo-1023404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="NICOLE WAILES" className='w-full h-auto mx-auto rounded-full border-4 border-green-500' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>LISA WATTS</span>
            <p className='text-sm'>
            BUSINESS DEVELOPMENT // Lisa brings a wealth of experience across environment and state govt, and has offered her heart and head to help us establish our not-for-profit farm. We are grateful for her insight and her ninja grant writing skills. 
            </p>
          </div>
          <div className='text-center'>
            <img src="https://images.pexels.com/photos/8126352/pexels-photo-8126352.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="NICOLE WAILES" className='w-full h-auto mx-auto rounded-full border-4 border-green-500' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>JACKY BROOKS</span>
            <p className='text-sm'>
            DESIGNER // Jacky is our creative guru, and is the woman behind our logo, farm signage, and making our website sparkle.  In her spare time, she has her own permaculture home patch, and flow hives - and is basically amazing. 
            </p>
          </div>
          <div className='text-center'>
            <img src="https://images.pexels.com/photos/464336/pexels-photo-464336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="NICOLE WAILES" className='w-full h-auto mx-auto rounded-full border-4 border-green-500' />
            <span className='inline-block mt-5 mb-2 text-lg font-semibold'>IAN HOLLAS</span>
            <p className='text-sm'>
            CHIEF GARDENER // Ian's contribution to creating our farm is beyond words. He has spent countless hours meticulously creating our garden beds, edging pathways, and mulching like crazy. His work has shaped our community farm, and left a true legacy,
            </p>
          </div>
        </div>
      </div>
      <div className='bg-[url("https://images.unsplash.com/photo-1533460004989-cef01064af7e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat w-full pt-20 pb-10'>
      <center>
        <div>
        <p className='text-white text-3xl font-bold'>Do you have questions?</p>
        <button className='bg-green-500 p-4 mt-10'>Get in touch</button>
        </div>
        </center>
      </div>
    </>
  )
}

export default Team
