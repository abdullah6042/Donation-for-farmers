import React, { useState } from 'react';
import './index.css'

const GetTicketsPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    quantity: 1
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleQuantityChange = (event) => {
    const quantity = parseInt(event.target.value);
    setFormData({ ...formData, quantity });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('/purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to purchase tickets');
      }

      const data = await response.json();
      // Handle success response from backend
      alert('Tickets purchased successfully!');
      // Reset form or navigate to a success page
      setFormData({
        name: '',
        email: '',
        quantity: 1
      });
    } catch (error) {
      // Handle error response from backend
      console.error('Error purchasing tickets:', error.message);
      alert('Failed to purchase tickets. Please try again later.');
    }
  };

  return (
    <div>
      <div className="banner">
        <h1 className="banner-title">Welcome to the Ticket Purchase Page</h1>
        <p className="banner-description">
          Purchase tickets for our upcoming event. Fill out the form below to proceed.
        </p>
      </div>
      <div className="container">
        <h2 className="title">Get Tickets</h2>
        <div className="ticket-form">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="quantity">Quantity:</label>
              <input
                type="number"
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleQuantityChange}
                min="1"
                max="10"
                required
              />
            </div>
            <button type="submit" className="submit-btn">Purchase Tickets</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default GetTicketsPage;
