import React from 'react'
import Slider from './Slider'
import Approved from './Approved'
function About() {
    return (
        <>
            <div className='bg-[url("https://images.unsplash.com/photo-1524601500432-1e1a4c71d692?q=80&w=2148&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-center w-full pt-20 pb-20 mb-20'>
                <p className='text-white text-4xl font-bold'>About Us</p>
            </div>
            <center>
                <img src="/favicon.png" alt="" width={100} />
            </center>
            <div>
                <p>
                    <span className='inline-block mb-10 text-green-600 font-bold text-4xl pl-20'>Our Vision</span> <br />
                </p>

            </div>
            <div className='text-xl pl-20'>
                Green Thumb Farm envisions a future where families feel empowered to make healthy food choices, actively <br /> supporting and valuing local, seasonal food, and confident with the know-how to grow some of their own food at <br />home and in schools.
            </div>
            <div>
                <p>
                    <span className='inline-block mb-10 text-green-600 font-bold text-4xl pl-20 mt-10'>What We Do?</span> <br />
                </p>

            </div>
            <div className='text-xl pl-20'>
                Green Thumb Farm is a community led social enterprise, located in the picturesque Samford Valley, just 35 mins from the CBD of Brisbane.  We are an educational community farm practising regenerative organic small scale farming, and we are advocates for supporting locally grown food.  We offer  community programs for families, school groups, adults and special needs groups, to visit and get involved in the farm.  We offer sustainable living workshops, corporate volunteering opportunities, and a community nursery.
            </div>
            <div>
                <p>
                    <span className='inline-block mb-10 text-green-600 font-bold text-4xl pl-20 mt-10'>Our Mission</span> <br />
                </p>

            </div>
            <div className='text-xl pl-20'>
                Our mission is to deepen the connection between families and their food, with a special focus on children. We want our younger generation to experience the joy of getting their hands dirty, better understand where their food comes from, and acquire an appreciation for seasonal local food.
            </div>
            <div>
                <p>
                    <span className='inline-block mb-10 text-green-600 font-bold text-4xl pl-20 mt-10'>Our Why</span> <br />
                </p>
            </div>
            <div className='text-xl pl-20 mb-20'>
                Our journey is driven by passion, innovation, and a deep-rooted commitment to enhancing better health outcomes for people and a healthier eco-system for the planet.
            </div>
            <p className='text-3xl font-bold text-center'>Image Gallery</p>

            <div className="flex items-center justify-center min-h-screen bg-gray-100">
                <Slider />
            </div>
            <span className='inline-block mb-10 mt-10 text-3xl text-green-600 font-bold ml-20'>The Need For Change</span> <br />
            <div className='ml-20'>

                Did you know that only 3.5% of Australian children eat the recommended amount of vegetables each week? Most supermarket produce is farmed in large scale monoculture farms and trucked long distances. Children and adults alike encounter food as packaged items in supermarkets, available year-round but often at a high cost to both families and the environment. <br /> <br />

                With two in three adults and one in four children living with overweight and obesity, and the associated burden of chronic disease, the cost to Queensland's health system is $756 million per year, and $11.8 billion nationwide.  The programs we run at Green Thumb Farm not only improve health outcomes, and reduce climate impacts, but in the process we reduce the economic burden of chronic disease for all Australians.
            </div>
            <span className='inline-block mb-10 mt-10 text-3xl text-green-600 font-bold ml-20'>Our Solution</span> <br />
            <div className='ml-20 mb-20'>

                Research shows that children who have the opportunity to touch, smell, and taste fresh vegetables early on are more likely to make healthier food choices as adults.  When school children, families and adults from right across SEQ visit Green Thumb Farm, they get hands on experiences of organic farming, composting, and sustainable agriculture that can change their trajectory for life. <br />
                <br />

                Green Thumb Farm offers an innovative approach to addressing the increasing burden of chronic disease in Australia through an educational community farm model that can be replicated in other parts of the country, including in our most vulnerable communities.
            </div>
            <div className='bg-[url("https://images.unsplash.com/photo-1524601500432-1e1a4c71d692?q=80&w=2148&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat w-full pt-10 pb-10 mb-10'>
            <center>
            <p className='text-white text-3xl font-bold'>It feels so good to get your hands in the dirt! </p>
            <button className='bg-green-500 mt-10 p-5 text-white text-xl'>Find out more</button>
            </center>
            </div>
            <Approved/>
        </>
    )
}

export default About
