import React from 'react';
import './index.css'; 

const DonatePage = () => {
  return (
    <div className="donate-container">
      <div className="banner">
        <h1 className="banner-title">Donate Online</h1>
        <p className="banner-description">
          Support our cause by making a donation online. Choose an amount and proceed securely.
        </p>
      </div>
      <div className="donate-form">
        <form>
          <div className="form-group">
            <label htmlFor="amount">Donation Amount:</label>
            <input type="number" id="amount" name="amount" min="1" placeholder="Enter amount" required />
          </div>
          <div className="form-group">
            <label htmlFor="cardNumber">Card Number:</label>
            <input type="text" id="cardNumber" name="cardNumber" placeholder="Enter card number" required />
          </div>
          {/* Additional form fields like name, email, etc. can be added here */}
          <button type="submit" className="donate-btn">Donate Now</button>
        </form>
      </div>
    </div>
  );
};

export default DonatePage;
