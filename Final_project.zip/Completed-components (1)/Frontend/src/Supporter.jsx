import React from 'react'

function Supporter() {
    return (
        <>
            <div className='bg-[url("https://plus.unsplash.com/premium_photo-1661901843315-899899a4be86?q=80&w=2121&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat'>
                <center>
                    <div>
                        <p className='text-6xl text-white font-bold pt-10'>Our Business Supporters</p>
                        <p className='text-4xl pb-20 pt-10 pl-20 pr-20 text-white'>Green Thumb Farm is a not-for-profit organisation and business supporters are key to enabling us to continue to grow and create new programs for the benefit of the community. </p>
                    </div>
                </center>
            </div>
            <div>
                <p className='text-4xl pt-20 pb-5 pl-10'>We Welcome Business Supporters</p>
            </div>
            <div>
                <p className='pl-10 pr-10 text-2xl'>As a valued business supporter you contribute directly to the growth of Green Thumb Farm, and impact our capacity to grow good in the community. We welcome donations of time, products, and funding that align with our mission at Green Thumb Farm.  <span className='font-bold'>Contact us today.</span></p>
            </div>
            <div>
                <div className='flex'>
                    <img src="/comp9.png" alt="" />
                    <p className='mt-10 ml-96'><span className='inline-block font-semibold text-2xl'>Aussie Tree Solutions</span> <br />
                        Aussie Tree Solutions has over 45 years of happy clients across SEQ. <br />

                        Thank you for supplying us with forest mulch free of charge!</p>
                </div>
                <div className='flex'>
                    <img src="/comp5.png" alt="" />
                    <p className=' ml-44 mt-10'><span className='inline-block font-semibold text-2xl'>Chelsea Perry from Craig Doyle Real Estate</span> <br />
                        Chelsea has always had a passion for real estate. She has lived in the region for over 17 years and is an active member in our local community. She is a leading agent in our region.

                        Thank you Chelsea and team for helping to make our refurbished workbench table in 2024, and for your donation of $300 in 2023. </p>
                </div>
                <div className='flex'>
                    <img src="/comp4.png" alt="" />
                    <p className=' ml-48 mt-10'><span className='inline-block font-semibold text-2xl'>New Day Psychology Services</span> <br />
                        Based in Camp Mountain, Denise Robertson is a clinical psycologist, with a love of the environment.She has a thriving edible garden of her own, and shares her property with her family, recue goats, 23 chooks, dog, pussy cats, wallabies, bandicoots, birdlife, reptiles and frogs!

                        Thank you Denise for your donation of $300 in 2023. </p>
                </div>
            </div>
            <div>
                <center>
                    <img src="/favicon.png" alt="" width={150} />
                    <p className='mt-10 mb-10 text-3xl font-bold'>Our Friend of the Farm Business Supporter Program</p>
                </center>
            </div>
            <div>
                <span className='inline-block mb-10 mt-10 text-green-600 text-3xl font-semibold ml-10'>Supporting a not-for-profit cause</span> <br />
                <p className='ml-10 text-2xl'>
                    By becoming a Business Supporter you contribute directly to Green Thumb Farm. Your membership fee goes towards sustaining and improving the farm's operations, supporting our education programs, and maintaining the farm's commitment to community enrichment through our garden programs.
                </p>
            </div>
            <div>
                <span className='inline-block mb-10 mt-10 text-green-600 text-3xl font-semibold ml-10'>You choose your level of support </span> <br />
                <p className='ml-10 text-2xl'>
                    Donating equipment or garden supplies, subscribing as a <span className='font-bold'>Business Friend</span> of the Farm program for $133/year, or giving your professional time to help us grow our business.
                </p>
            </div>
            <div>
                <span className='inline-block mb-10 mt-10 text-green-600 text-3xl font-semibold ml-10'>Supporting a not-for-profit cause</span> <br />
                <p className='ml-10 text-2xl'>
                    By becoming a Business Supporter you contribute directly to Green Thumb Farm. Your membership fee goes towards sustaining and improving the farm's operations, supporting our education programs, and maintaining the farm's commitment to community enrichment through our garden programs.
                </p>
            </div>
            <div>
                <span className='inline-block mb-10 mt-10 text-green-600 text-3xl font-semibold ml-10'>Supporting a not-for-profit cause</span> <br />
                <p className='ml-10 text-2xl'>
                    By becoming a Business Supporter you contribute directly to Green Thumb Farm. Your membership fee goes towards sustaining and improving the farm's operations, supporting our education programs, and maintaining the farm's commitment to community enrichment through our garden programs.
                </p>
            </div>
            <div>
                <p><span className='inline-block p-10 text-3xl font-bold'>Ready, set go!</span> <br />
                    <p className='pl-10 pr-10 text-xl'>
                        Begin your journey with Green Thumb Farm by clicking on the provided button, positioning yourself as an integral supporter helping us achieve our purpose and mission.
                    </p>
                </p>
            </div>
            <div>
                <center>
                    <img src="/favicon.png" alt="" className='border-4 rounded-md w-[120px] h-[120px] p-5' />
                </center>
            </div>
            <div>
                <p className='text-s text-center mt-3 mb-3'>Friend of the Farm - Business</p>
            </div>
            <div className='flex justify-center'>
                <p><span className='text-5xl'>A$133</span>
                    per
                    year</p>
            </div>
            <div>
                <center>
                    <button className='bg-green-500 p-3 mt-10 rounded-md font-bold w-96'>Subscribe</button>
                </center>
            </div>
            <p className='font-thin text-center mt-2'>Supported payment methods:</p>
            <div className='flex justify-center mb-20'>
                <img src="/card1.png" alt="" width={30} height={10}/>
                <img src="/card2.png" alt="" width={30} height={10} className='ml-5 mr-5'/>
                <img src="/card3.png" alt="" width={30} height={10} className='ml-5 mr-5'/>
                <img src="/card4.png" alt="" width={30} height={5} className='ml-5 mr-5'/>
                <img src="/card5.png" alt="" width={30} height={10}/>
            </div>
        </>
    )
}

export default Supporter
