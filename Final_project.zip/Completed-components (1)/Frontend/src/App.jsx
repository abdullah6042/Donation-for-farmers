import './index.css';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import About from './About';
import Contact from './Contact';
import Donors from './Donors';
import Footer from './Footer';
import Home from './Home';
import Navbar from './Navbar';
import Saturday from './Saturday'; 
import Supporter from './Supporter';
import Team from './Team';
import GetTickets from './GetTickets'; 
import Donate from './Donate';
import Login from './login';
import Register from './Register';

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/about' element={<About />} />
        <Route path='/team' element={<Team />} />
        <Route path='/supporters' element={<Supporter />} />
        <Route path='/donors' element={<Donors />} />
        <Route path='/farmgate' element={<Saturday />} />
        <Route path='/get-tickets' element={<GetTickets />} />
        <Route path='/donate' element={<Donate />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
