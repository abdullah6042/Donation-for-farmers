import React from 'react'

function Newsletter() {
  return (
    <>
    <div className='bg-[url("https://images.unsplash.com/photo-1533460004989-cef01064af7e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-center h-full w-full mt-36'>
                <div className='bg-zinc-950 pl-96 pr-96 mt-36 mb-36 opacity-75 p-20'>
                    <center>
                        <div className='flex w-full'>
                            <p className='mr-20 w-full text-white'><span className='text-2xl'>GREEN THUMB NEWS</span> <br />
                            Find out first about activities, events, and all things good at Green Thumb.</p>
                            <form action="">
                                <input type="text" className='w-96 h-10'/>
                                <input type="text" className='w-96 h-10 mt-8'/>
                                <button className='bg-green-400 p-3 w-full mt-10'>GET OUR UPDATES</button>
                            </form>
                        </div>
                    </center>
                </div>
                </div>
    </>
  )
}

export default Newsletter
