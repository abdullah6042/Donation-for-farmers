import React from 'react'

function Saturday() {
    return (
        <>
            <div className='bg-[url("https://plus.unsplash.com/premium_photo-1688671925771-88af81154ab5?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat w-full pt-20 pb-20 mb-20 h-[50vh]'>
                <p className='text-5xl text-center text-white font-bold'>Experience the Magic of Green Thumb Farm</p>
                <p className='text-center mt-10 text-xl text-white font-semibold'>Every Saturday: 9am - 11am </p>
            </div>
            <div>
                <p className='text-3xl'>Market Stall & Nursery every Saturday morning 9am - 11am</p>
                <p>Organic Produce -  Community Nursery - Fresh Flowers - Artisan Sourdough - Coffee! </p>
            </div>
            <div>
                Drop in to our FarmGate stall on Saturday mornings for some fresh, locally grown produce!  Get your hands on our delicious seasonal goodies picked fresh that morning and support a great cause with every purchase you make of our locally grown produce - all organic and spray free of courseinline! <br /><br />
            </div>
            <ul className="list-disc">
                <li>Fresh, Organic Produce picked straight from the Farm</li>
                <li>Microgreens to supercharge your health</li>
                <li>Organic, local sourdough bread, pastries and cookies.</li>
            </ul>
        </>
    )
}

export default Saturday
