import { NavLink } from 'react-router-dom'
import Newsletter from './Newsletter'
import Approved from './Approved'
function Home() {
    return (
        <>
            <div className='bg-[url("https://images.unsplash.com/photo-1576328556242-35346f470f79?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-end h-full w-full'>
                <img src="/Logo.png" alt="" className='bg-transparent' width={543} height={477} />
            </div>
            <div className='h-full bg-green-400 text-4xl font-serif font-bold text-white text-center p-3'>
                <h1>Growing Good at Green Thumb Farm</h1>
            </div>
            <div className='pb-10'>
                <center>
                    <img src="/favicon.png" alt="" width={60} height={60} />
                </center>
            </div>
            <div>
                <p className='text-4xl text-center font-sans font-bold pb-10'>
                    We are an educational community farm with a BIG goal:
                </p>
            </div>
            <div>
                <p className='text-center pb-10'>To deepen the connection between families and their food, with a special focus on children. We want our younger generation to experience the joy of getting their hands dirty, better understand where their food comes from, and acquire an appreciation for seasonal local food.</p>
            </div>
            <div className='grid-flow-col flex justify-center'>
                <img src="https://images.unsplash.com/photo-1576328556242-35346f470f79?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width={400} height={400} className='' />
                <img src="https://plus.unsplash.com/premium_photo-1664193516160-27a3fa05901e?q=80&w=2110&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width={400} height={400} className='ml-5' />
                <img src="https://images.unsplash.com/photo-1506634064465-7dab4de896ed?q=80&w=2187&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width={400} height={400} className='pl-5' />
            </div>
            <div className='flex w-full'>
                <p className=' ml-20 w-96 text-center text-3xl pt-10 pb-10'>Organic produce
                and seedlings</p>
                <p className='ml-20 text-3xl pt-10 pb-10'> Community Volunteering</p>
                <p className='ml-32 text-3xl pt-10 pb-10'> Corporate Volunteering</p>
            </div>
            <div className='bg-[url("https://plus.unsplash.com/premium_photo-1681885188467-049532b7b9ea?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat justify-center h-full w-full'>
                <p className='mt-10 mb-10 text-4xl text-white font-bold text-center pt-28 pb-5'>Become a Friend of Green Thumb Farm</p>
                <p className='text-center pl-5 pr-5 text-white pb-5 text-xl'>Our Farm Friends program is a small contribution that goes a long way - <br />only $33 a year for families. Thank you for your support! </p>
                <center>
                    <button className='bg-green-400 p-4 mb-10'>Become a Friend of Green Thumb Farm Today</button>
                </center>
            </div>
            <div className='grid-flow-row'>
      <h1 className='text-center font-sans text-3xl font-bold mb-10'>Upcoming events</h1>
      <div className='grid-flow-col'>
        <div className='flex justify-center'>
          <div className='border-2 flex'>
            <img src="/pic2.png" alt="" />
            <div>
              <p>Harvesting & Healing Properties of Winter Wild Greens <br />
                Sat 13th Jul 2024, 10:00 am - 12:00 pm AEST <br />
                Acte Ww
                2204 Mount Samson Rd, Samford Valley QLD 4520, Australia <br />
                $65-$170 AUD + BF</p>
              <NavLink to="/get-tickets">
                <button className='items-end mt-4 w-36 bg-green-400 p-2'>Get Tickets</button>
              </NavLink>
            </div>
          </div>
        </div>
        
        <div className='flex justify-center'>
          <div className='border-2 flex'>
            <img src="/pic2.png" alt="" />
            <div>
              <p>Harvesting & Healing Properties of Winter Wild Greens <br />
                Sat 13th Jul 2024, 10:00 am - 12:00 pm AEST <br />
                Acte Ww
                2204 Mount Samson Rd, Samford Valley QLD 4520, Australia <br />
                $65-$170 AUD + BF</p>
              <NavLink to="/get-tickets">
                <button className='items-end mt-4 w-36 bg-green-400 p-2'>Get Tickets</button>
              </NavLink>
            </div>
          </div>
        </div>

        <div className='flex justify-center'>
          <div className='border-2 flex'>
            <img src="/pic2.png" alt="" />
            <div>
              <p>Harvesting & Healing Properties of Winter Wild Greens <br />
                Sat 13th Jul 2024, 10:00 am - 12:00 pm AEST <br />
                Acte Ww
                2204 Mount Samson Rd, Samford Valley QLD 4520, Australia <br />
                $65-$170 AUD + BF</p>
              <NavLink to="/get-tickets">
                <button className='items-end mt-4 w-36 bg-green-400 p-2'>Get Tickets</button>
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </div>
            <div className='bg-[url("https://images.unsplash.com/photo-1533460004989-cef01064af7e?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")] bg-cover bg-no-repeat flex justify-center h-full w-full mt-36'>
                <div className='bg-zinc-950 pl-96 pr-96 mt-36 mb-36 opacity-75'>
                    <center>
                        <img src="/favicon.png" alt="" width={100} className='mt-5 mb-5' />
                        <p className='text-white pb-2'>Green Thumb Farm is in the picturesque Samford Valley, QLD.</p>
                        <p className='text-white pb-2 pt-2'>Come along to our FarmGate Sales every Saturday from 9am - 11am!</p>
                        <p className='text-white pt-2'>Seasonal Edible Nursery | Fresh Organic Produce | Delicious Coffee</p>
                        <div className='bg-white w-72 mt-10 mb-10'>
                            2204 Mt Samson Rd, Samford Valley, Qld
                        </div>
                    </center>
                </div>
            </div>
            <div className='pt-5'>
                <p className='text-3xl text-center font-bold pb-20'>Our Grant Donors, Sponsors & Supporters</p>
                <div className='w-full'>
                    <div className='grid-flow-col flex justify-center'>

                        <img src="/comp1.png" alt="" width={200} height={400} />
                        <img src="/comp2.png" alt="" width={200} height={400} />
                        <img src="/comp3.png" alt="" width={200} height={400} />
                        <img src="/comp4.png" alt="" width={200} height={400} />
                        <img src="/comp5.png" alt="" width={200} height={400} />

                    </div>
                    <div className='ml-0 grid-flow-col flex justify-center'>
                        <img src="/comp6.png" alt="" width={200} height={400} />
                        <img src="/comp7.png" alt="" width={200} height={400} />
                        <img src="/comp8.png" alt="" width={200} height={400} />
                        <img src="/comp9.png" alt="" width={200} height={400} />
                    </div>
                </div>
            </div>
            <Newsletter/>
            <Approved/>
        </>
    )
}

export default Home
