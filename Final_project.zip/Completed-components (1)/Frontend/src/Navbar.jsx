import './index.css'
import React from 'react'
import { NavLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <div className='bg-zinc-600 w-full flex justify-end'>
      <img src="/Logo.png" alt="" className='mr-auto' width={230} />
      
      <NavLink to="/" className='text-xl pr-10 mt-11 text-white'>Home</NavLink>
      <NavLink to="/about" className='text-xl pr-10 mt-11 text-white'>About</NavLink>

      <NavLink to="/Team" className='text-xl pr-10 mt-11 text-white'>Our Team</NavLink>

      <NavLink to="/contact" className='text-xl pr-10 mt-11 text-white'>Contact Us</NavLink>

      <NavLink to="/donors" className='text-xl pr-10 mt-11 text-white'>Donors</NavLink>

      <NavLink to="/supporters" className='text-xl pr-10 mt-11 text-white'>Supporters</NavLink>

      <NavLink to="/farmgate" className='text-xl pr-10 mt-11 text-white'>Farmgate</NavLink>
      <NavLink to="/login" className='text-xl pr-10 mt-11 text-white'>Login</NavLink>


      {/* <select className='bg-transparent text-xl pr-10 text-center text-white'>
        <option value="/about" className='bg-zinc-600'>About Us</option>
        <option value="/team" className='bg-zinc-600'>Our Team</option>
        <option value="/supporters" className='bg-zinc-600'>Our Business Supporters</option>
        <option value="/donors" className='bg-zinc-600'>Our Grant Donors</option>
      </select>
      
      <select className='bg-transparent text-xl pr-10 text-center text-white'>
        <option value="/farmgate" className='bg-zinc-600'>FarmGate & Nursery</option>
        <option value="/workshops" className='bg-zinc-600'>Workshops</option>
        <option value="/programs" className='bg-zinc-600'>Garden Programs</option>
        <option value="/activities" className='bg-zinc-600'>Children's Activities</option>
        <option value="/excursions" className='bg-zinc-600'>School Excursions</option>
      </select>
      
      <select className='bg-transparent text-xl pr-10 text-center text-white'>
        <option value="/farmfriends" className='bg-zinc-600'>Farm Friends</option>
        <option value="/volunteering" className='bg-zinc-600'>Volunteering</option>
        <option value="/corporate" className='bg-zinc-600'>Corporate Volunteering</option>
      </select>
      
      <NavLink to="/contact" className="mt-11 text-xl pr-10 pl-10 text-white">Contact Us</NavLink> */}
      
      <NavLink to="/donate" className="donate">Donate Now</NavLink>
    </div>
  )
}

export default Navbar
