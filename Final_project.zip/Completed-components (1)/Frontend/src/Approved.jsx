import React from 'react'

function Approved() {
    return (
        <>
            <div>
                <center>
                    <img src="/pic3.png" alt="" width={152} height={14} />
                </center>
            </div>
        </>
    )
}

export default Approved
