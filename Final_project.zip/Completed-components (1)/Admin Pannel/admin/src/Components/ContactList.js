import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const ContactList = () => {
  const [contactList, setContactList] = useState([]);
  const [error, setError] = useState(null);
  const [editContact, setEditContact] = useState(null);
  const [newContact, setNewContact] = useState({ name: '', email: '', message: '' });

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = () => {
    axios.get('http://localhost:5000/getContact')
      .then(response => setContactList(response.data))
      .catch(err => {
        console.error('Error fetching contact list:', err);
        setError('Failed to fetch contact data.');
      });
  };

  const deleteContact = (id) => {
    axios.delete(`http://localhost:5000/deleteContact/${id}`)
      .then(() => fetchContacts())
      .catch(err => console.error('Error deleting contact:', err));
  };

  const handleEditChange = (e) => {
    setEditContact({
      ...editContact,
      [e.target.name]: e.target.value,
    });
  };

  const updateContact = (id) => {
    axios.put(`http://localhost:5000/updateContact/${id}`, editContact)
      .then(() => {
        fetchContacts();
        setEditContact(null);
      })
      .catch(err => console.error('Error updating contact:', err));
  };

  const handleAddChange = (e) => {
    setNewContact({
      ...newContact,
      [e.target.name]: e.target.value,
    });
  };

  const addContact = () => {
    axios.post(`http://localhost:5000/addContact`, newContact)
      .then(() => {
        fetchContacts();
        setNewContact({ name: '', email: '', message: '' });
      })
      .catch(err => console.error('Error adding contact:', err));
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <nav className="col-md-3 col-lg-2 d-md-block bg-light sidebar">
          <div className="sidebar-sticky">
            <ul className="nav flex-column">
              <li className="nav-item">
                <Link to="/" className="nav-link text-dark">
                  <i className="fas fa-home mr-2"></i> Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/contact" className="nav-link text-dark">
                  <i className="fas fa-envelope mr-2"></i> Contact List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/login" className="nav-link text-dark">
                  <i className="fas fa-user-lock mr-2"></i> Login List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-link text-dark">
                  <i className="fas fa-user-plus mr-2"></i> Register List
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        {/* Main Content */}
        <main className="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <h3 className="mt-5 mb-4">Contact List</h3>
          {error && <div className="alert alert-danger">{error}</div>}
          <table className="table table-striped table-bordered">
            <thead className="thead-dark">
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {contactList.map(contact => (
                <tr key={contact._id}>
                  {editContact && editContact._id === contact._id ? (
                    <>
                      <td>
                        <input
                          type="text"
                          name="name"
                          value={editContact.name}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <input
                          type="email"
                          name="email"
                          value={editContact.email}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          name="message"
                          value={editContact.message}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <button className="btn btn-success mr-2" onClick={() => updateContact(contact._id)}>Save</button>
                        <button className="btn btn-secondary" onClick={() => setEditContact(null)}>Cancel</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{contact.name}</td>
                      <td>{contact.email}</td>
                      <td>{contact.message}</td>
                      <td>
                        <button className="btn btn-danger mr-2" onClick={() => deleteContact(contact._id)}>Delete</button>
                        <button className="btn btn-primary" onClick={() => setEditContact(contact)}>Edit</button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          
          <h3 className="mt-5">Add New Contact</h3>
          <div className="form-group">
            <input
              type="text"
              name="name"
              value={newContact.name}
              onChange={handleAddChange}
              placeholder="Name"
              className="form-control mb-2"
            />
            <input
              type="email"
              name="email"
              value={newContact.email}
              onChange={handleAddChange}
              placeholder="Email"
              className="form-control mb-2"
            />
            <input
              type="text"
              name="message"
              value={newContact.message}
              onChange={handleAddChange}
              placeholder="Message"
              className="form-control mb-2"
            />
            <button className="btn btn-primary" onClick={addContact}>Add Contact</button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ContactList;
