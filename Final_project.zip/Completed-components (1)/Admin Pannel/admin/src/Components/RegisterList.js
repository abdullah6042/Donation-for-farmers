import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const RegisterList = () => {
  const [registerList, setRegisterList] = useState([]);
  const [error, setError] = useState(null);
  const [editRegister, setEditRegister] = useState(null);
  const [newRegister, setNewRegister] = useState({ name: '', email: '', password: '' });

  useEffect(() => {
    fetchRegisters();
  }, []);

  const fetchRegisters = () => {
    axios.get('http://localhost:5000/getRegister')
      .then(response => setRegisterList(response.data))
      .catch(err => {
        console.error('Error fetching register list:', err);
        setError('Failed to fetch register data.');
      });
  };

  const deleteRegister = (id) => {
    axios.delete(`http://localhost:5000/deleteRegister/${id}`)
      .then(() => fetchRegisters())
      .catch(err => console.error('Error deleting register:', err));
  };

  const handleEditChange = (e) => {
    setEditRegister({
      ...editRegister,
      [e.target.name]: e.target.value,
    });
  };

  const updateRegister = (id) => {
    axios.put(`http://localhost:5000/updateRegister/${id}`, editRegister)
      .then(() => {
        fetchRegisters();
        setEditRegister(null);
      })
      .catch(err => console.error('Error updating register:', err));
  };

  const handleAddChange = (e) => {
    setNewRegister({
      ...newRegister,
      [e.target.name]: e.target.value,
    });
  };

  const addRegister = () => {
    axios.post('http://localhost:5000/addRegister', newRegister)
      .then(() => {
        fetchRegisters();
        setNewRegister({ name: '', email: '', password: '' });
      })
      .catch(err => console.error('Error adding register:', err));
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <nav className="col-md-3 col-lg-2 d-md-block bg-light sidebar">
          <div className="sidebar-sticky">
            <ul className="nav flex-column">
              <li className="nav-item">
                <Link to="/" className="nav-link text-dark">
                  <i className="fas fa-home mr-2"></i> Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/contact" className="nav-link text-dark">
                  <i className="fas fa-envelope mr-2"></i> Contact List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/login" className="nav-link text-dark">
                  <i className="fas fa-user-lock mr-2"></i> Login List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-link text-dark">
                  <i className="fas fa-user-plus mr-2"></i> Register List
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        {/* Main Content */}
        <main className="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <h3 className="mt-5 mb-4">Register List</h3>
          {error && <div className="alert alert-danger">{error}</div>}
          <table className="table table-striped table-bordered">
            <thead className="thead-dark">
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {registerList.map(register => (
                <tr key={register._id}>
                  {editRegister && editRegister._id === register._id ? (
                    <>
                      <td>
                        <input
                          type="text"
                          name="name"
                          value={editRegister.name}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <input
                          type="email"
                          name="email"
                          value={editRegister.email}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          name="password"
                          value={editRegister.password}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <button className="btn btn-success mr-2" onClick={() => updateRegister(register._id)}>Save</button>
                        <button className="btn btn-secondary" onClick={() => setEditRegister(null)}>Cancel</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{register.name}</td>
                      <td>{register.email}</td>
                      <td>{register.password}</td>
                      <td>
                        <button className="btn btn-danger mr-2" onClick={() => deleteRegister(register._id)}>Delete</button>
                        <button className="btn btn-primary" onClick={() => setEditRegister(register)}>Edit</button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>

          <h3 className="mt-5">Add New Register</h3>
          <div className="form-group">
            <input
              type="text"
              name="name"
              value={newRegister.name}
              onChange={handleAddChange}
              placeholder="Name"
              className="form-control mb-2"
            />
            <input
              type="email"
              name="email"
              value={newRegister.email}
              onChange={handleAddChange}
              placeholder="Email"
              className="form-control mb-2"
            />
            <input
              type="text"
              name="password"
              value={newRegister.password}
              onChange={handleAddChange}
              placeholder="Password"
              className="form-control mb-2"
            />
            <button className="btn btn-primary" onClick={addRegister}>Add Register</button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default RegisterList;
