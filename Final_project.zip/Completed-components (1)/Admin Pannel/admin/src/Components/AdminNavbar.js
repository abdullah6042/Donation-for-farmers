import React from 'react';
import { Link } from 'react-router-dom';
import './AdminNavbar.css'; // Import your custom CSS file for AdminNavbar styling

const AdminNavbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container d-flex justify-content-center">
        <Link className="navbar-brand" to="/admin">Admin Panel</Link>
      </div>
    </nav>
  );
};

export default AdminNavbar;
