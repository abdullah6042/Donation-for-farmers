import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const LoginList = () => {
  const [loginList, setLoginList] = useState([]);
  const [error, setError] = useState(null);
  const [editLogin, setEditLogin] = useState(null);
  const [newLogin, setNewLogin] = useState({ email: '', password: '' });

  useEffect(() => {
    fetchLogins();
  }, []);

  const fetchLogins = () => {
    axios.get('http://localhost:5000/getLogin')
      .then(response => setLoginList(response.data))
      .catch(err => {
        console.error('Error fetching contact list:', err);
        setError('Failed to fetch contact data.');
      });
  };

  const deleteLogin = (id) => {
    axios.delete(`http://localhost:5000/deleteLogin/${id}`)
      .then(() => fetchLogins())
      .catch(err => console.error('Error deleting contact:', err));
  };

  const handleEditChange = (e) => {
    setEditContact({
      ...editLogin,
      [e.target.email]: e.target.value,
    });
  };

  const updateLogin = (id) => {
    axios.put(`http://localhost:5000/updateLogin/${id}`, editLogin)
      .then(() => {
        fetchLogins();
        setEditLogin(null);
      })
      .catch(err => console.error('Error updating contact:', err));
  };

  const handleAddChange = (e) => {
    setNewContact({
      ...newLogin,
      [e.target.email]: e.target.value,
    });
  };

  const addLogin = () => {
    axios.post(`http://localhost:5000/addLogin`, newLogin)
      .then(() => {
        fetchLogins();
        setNewLogin({ email: '', password: '' });
      })
      .catch(err => console.error('Error adding contact:', err));
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <nav className="col-md-3 col-lg-2 d-md-block bg-light sidebar">
          <div className="sidebar-sticky">
            <ul className="nav flex-column">
              <li className="nav-item">
                <Link to="/" className="nav-link text-dark">
                  <i className="fas fa-home mr-2"></i> Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/contact" className="nav-link text-dark">
                  <i className="fas fa-envelope mr-2"></i> Contact List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/login" className="nav-link text-dark">
                  <i className="fas fa-user-lock mr-2"></i> Login List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-link text-dark">
                  <i className="fas fa-user-plus mr-2"></i> Register List
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        {/* Main Content */}
        <main className="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <h3 className="mt-5 mb-4">Login List</h3>
          {error && <div className="alert alert-danger">{error}</div>}
          <table className="table table-striped table-bordered">
            <thead className="thead-dark">
              <tr>
                <th>Email</th>
                <th>Password</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loginList.map(login => (
                <tr key={login._id}>
                  {editLogin && editLogin._id === login._id ? (
                    <>
                      <td>
                        <input
                          type="email"
                          name="email"
                          value={editLogin.email}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          name="password"
                          value={editLogin.password}
                          onChange={handleEditChange}
                          className="form-control"
                        />
                      </td>
                      <td>
                        <button className="btn btn-success mr-2" onClick={() => updateLogin(login._id)}>Save</button>
                        <button className="btn btn-secondary" onClick={() => setEditLogin(null)}>Cancel</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{login.email}</td>
                      <td>{login.password}</td>
                      <td>
                        <button className="btn btn-danger mr-2" onClick={() => deleteLogin(login._id)}>Delete</button>
                        <button className="btn btn-primary" onClick={() => setEditLogin(login)}>Edit</button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          
          <h3 className="mt-5">Add New Login</h3>
          <div className="form-group">
            <input
              type="email"
              name="email"
              value={newLogin.email}
              onChange={handleAddChange}
              placeholder="Email"
              className="form-control mb-2"
            />
            <input
              type="text"
              name="password"
              value={newLogin.password}
              onChange={handleAddChange}
              placeholder="Password"
              className="form-control mb-2"
            />
            <button className="btn btn-primary" onClick={addLogin}>Add Login</button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default LoginList;
