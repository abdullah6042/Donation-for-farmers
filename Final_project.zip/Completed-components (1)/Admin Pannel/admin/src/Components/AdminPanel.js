import React, { useState, useEffect } from 'react';
import './AdminPanel.css'; // Custom CSS for AdminPanel styling
import { Link } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminPanel = () => {
  const [contactList, setContactList] = useState([]);
  const [loginList, setLoginList] = useState([]);
  const [registerList, setRegisterList] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/getContact')
      .then(response => setContactList(response.data))
      .catch(err => {
        console.error('Error fetching contact list:', err);
        setError('Failed to fetch contact data.');
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/getLogin')
      .then(response => setLoginList(response.data))
      .catch(err => {
        console.error('Error fetching Login list:', err);
        setError('Failed to fetch Login data.');
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/getRegister')
      .then(response => setRegisterList(response.data))
      .catch(err => {
        console.error('Error fetching Register list:', err);
        setError('Failed to fetch Register data.');
      });
  }, []);

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <nav className="col-md-3 col-lg-2 d-md-block bg-light sidebar">
          <div className="sidebar-sticky">
            <ul className="nav flex-column">
              <li className="nav-item">
                <Link to="/" className="nav-link text-dark">
                  <i className="fas fa-home mr-2"></i> Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/contact" className="nav-link text-dark">
                  <i className="fas fa-envelope mr-2"></i> Contact List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/login" className="nav-link text-dark">
                  <i className="fas fa-user-lock mr-2"></i> Login List
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-link text-dark">
                  <i className="fas fa-user-plus mr-2"></i> Register List
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        {/* Main content area */}
        <main role="main" className="col-md-9 ml-sm-auto col-lg-10 px-md-4">
          <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 className="h2">Dashboard</h1>
          </div>

          {error && <div className="alert alert-danger">{error}</div>}

          {/* Display Contact List */}
          <div className="mt-4">
            <h3>Contact List</h3>
            <table className="table table-striped table-bordered">
              <thead className="thead-dark">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Message</th>
                </tr>
              </thead>
              <tbody>
                {contactList.map(contact => (
                  <tr key={contact._id}>
                    <td>{contact.name}</td>
                    <td>{contact.email}</td>
                    <td>{contact.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Display Login List */}
          <div className="mt-4">
            <h3>Login List</h3>
            <table className="table table-striped table-bordered">
              <thead className="thead-dark">
                <tr>
                  <th>Email</th>
                  <th>Password</th>
                </tr>
              </thead>
              <tbody>
                {loginList.map(login => (
                  <tr key={login._id}>
                    <td>{login.email}</td>
                    <td>{login.password}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Display Register List */}
          <div className="mt-4">
            <h3>Register List</h3>
            <table className="table table-striped table-bordered">
              <thead className="thead-dark">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Password</th>
                </tr>
              </thead>
              <tbody>
                {registerList.map(register => (
                  <tr key={register._id}>
                    <td>{register.name}</td>
                    <td>{register.email}</td>
                    <td>{register.password}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
